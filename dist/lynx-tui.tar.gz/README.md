 # LYNX TUI
 
 Full-screen terminal UI for managing a LYNX blockchain node. Built with Textual.
 
 ## Quick start (placeholder)
 
 ```
 wget -qO- https://example.com/lynx-tui/bootstrap.sh | bash
 ```
 
 This downloads and runs the installer, which sets up dependencies, installs the app,
 and enables a sync-wait service that launches the TUI after the node finishes syncing.
