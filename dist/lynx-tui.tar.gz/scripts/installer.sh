 #!/bin/bash
 
 set -euo pipefail
 
APP_TARBALL_URL="${APP_TARBALL_URL:-https://example.com/lynx-tui/lynx-tui.tar.gz}"
 INSTALL_ROOT="/usr/local/lynx-tui"
 APP_DIR="${INSTALL_ROOT}/app"
 VENV_DIR="${INSTALL_ROOT}/venv"
 
 require_root() {
   if [ "$EUID" -ne 0 ]; then
     echo "Please run as root."
     exit 1
   fi
 }
 
 detect_os() {
   if [ -f /etc/os-release ]; then
     . /etc/os-release
     case "$ID" in
       debian|ubuntu) OS_FAMILY="debian" ;;
       rhel|centos|fedora|rocky|almalinux|ol) OS_FAMILY="redhat" ;;
       *) OS_FAMILY="unknown" ;;
     esac
   else
     OS_FAMILY="unknown"
   fi
 }
 
 install_packages() {
   if [ "$OS_FAMILY" = "debian" ]; then
     apt-get update -y
     apt-get install -y python3 python3-venv python3-pip curl htop iptables
   elif [ "$OS_FAMILY" = "redhat" ]; then
     if command -v dnf >/dev/null 2>&1; then
       dnf install -y python3 python3-pip python3-virtualenv curl htop iptables
     else
       yum install -y python3 python3-pip python3-virtualenv curl htop iptables
     fi
   else
     echo "Unsupported OS family. Install python3 and pip manually."
   fi
 }
 
 fetch_app() {
   mkdir -p "$APP_DIR"
   rm -rf "$APP_DIR"/*
   echo "Downloading app bundle..."
   if command -v curl >/dev/null 2>&1; then
     curl -fsSL "$APP_TARBALL_URL" -o "${INSTALL_ROOT}/app.tar.gz"
   else
     wget -qO "${INSTALL_ROOT}/app.tar.gz" "$APP_TARBALL_URL"
   fi
   tar -xzf "${INSTALL_ROOT}/app.tar.gz" -C "$APP_DIR" --strip-components=1
 }
 
 install_app() {
   python3 -m venv "$VENV_DIR"
   "$VENV_DIR/bin/pip" install --upgrade pip
   "$VENV_DIR/bin/pip" install "$APP_DIR"
 }
 
 install_launcher() {
   cat <<'EOF' > /usr/local/bin/lynx-tui
#!/bin/bash
exec /usr/local/lynx-tui/venv/bin/python -m lynx_tui
EOF
   chmod +x /usr/local/bin/lynx-tui
 }
 
 install_sync_wait_script() {
   cat <<'EOF' > "${INSTALL_ROOT}/sync-wait.sh"
#!/bin/bash

set -euo pipefail

WORKING_DIR="${LYNX_WORKING_DIR:-/var/lib/lynx}"
RPC_CLI="/usr/local/bin/lynx-cli"

if [ ! -x "$RPC_CLI" ]; then
  exit 0
fi

info=$("$RPC_CLI" -datadir="$WORKING_DIR" getblockchaininfo 2>/dev/null || true)
if echo "$info" | grep -q '"initialblockdownload":[[:space:]]*false'; then
  systemctl enable lynx-tui.service >/dev/null 2>&1 || true
  systemctl start lynx-tui.service >/dev/null 2>&1 || true
  systemctl stop lynx-sync-wait.timer >/dev/null 2>&1 || true
  systemctl disable lynx-sync-wait.timer >/dev/null 2>&1 || true
fi
EOF
   chmod +x "${INSTALL_ROOT}/sync-wait.sh"
 }
 
 install_systemd_units() {
   cat <<'EOF' > /etc/systemd/system/lynx-tui.service
[Unit]
Description=LYNX TUI
After=network.target lynx.service
Wants=network.target

[Service]
Type=simple
ExecStart=/usr/local/bin/lynx-tui
Restart=on-failure
User=root
WorkingDirectory=/root
Environment=LYNX_WORKING_DIR=/var/lib/lynx

[Install]
WantedBy=multi-user.target
EOF

   cat <<'EOF' > /etc/systemd/system/lynx-sync-wait.service
[Unit]
Description=Wait for LYNX sync completion
After=network.target lynx.service

[Service]
Type=oneshot
ExecStart=/usr/local/lynx-tui/sync-wait.sh
EOF

   cat <<'EOF' > /etc/systemd/system/lynx-sync-wait.timer
[Unit]
Description=Check LYNX sync status

[Timer]
OnBootSec=2min
OnUnitActiveSec=5min
Unit=lynx-sync-wait.service

[Install]
WantedBy=timers.target
EOF

   systemctl daemon-reload
   systemctl enable lynx-sync-wait.timer
   systemctl start lynx-sync-wait.timer
 }
 
 main() {
   require_root
   detect_os
   install_packages
   fetch_app
   install_app
   install_launcher
   install_sync_wait_script
   install_systemd_units
   echo "LYNX TUI installed. It will start automatically after sync completes."
 }
 
 main "$@"
