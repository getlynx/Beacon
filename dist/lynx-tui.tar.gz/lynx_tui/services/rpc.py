 import json
 import os
 from datetime import datetime, timedelta, timezone
 from pathlib import Path
 from typing import Any, Dict, List, Optional
 
 import requests
 
 
 class RpcClient:
     def __init__(self) -> None:
         self.working_dir = os.environ.get("LYNX_WORKING_DIR", "/var/lib/lynx")
         self.conf_path = os.environ.get("LYNX_CONF", f"{self.working_dir}/lynx.conf")
         self.rpc_user = os.environ.get("LYNX_RPC_USER")
         self.rpc_password = os.environ.get("LYNX_RPC_PASSWORD")
         self.rpc_host = os.environ.get("LYNX_RPC_HOST", "127.0.0.1")
         self.rpc_port = os.environ.get("LYNX_RPC_PORT")
         self._load_conf()
 
     def _load_conf(self) -> None:
         path = Path(self.conf_path)
         if not path.exists():
             return
         for line in path.read_text().splitlines():
             line = line.strip()
             if not line or line.startswith("#") or "=" not in line:
                 continue
             key, value = line.split("=", 1)
             key = key.strip().lower()
             value = value.strip()
             if key == "rpcuser" and not self.rpc_user:
                 self.rpc_user = value
             elif key == "rpcpassword" and not self.rpc_password:
                 self.rpc_password = value
             elif key == "rpcport" and not self.rpc_port:
                 self.rpc_port = value
             elif key == "rpcbind" and self.rpc_host == "127.0.0.1":
                 self.rpc_host = value
             elif key == "rpchost" and self.rpc_host == "127.0.0.1":
                 self.rpc_host = value
 
     def _rpc_url(self) -> str:
         port = self.rpc_port or "8332"
         return f"http://{self.rpc_host}:{port}"
 
     def _rpc_call(self, method: str, params: Optional[list] = None) -> Any:
         if not self.rpc_user or not self.rpc_password:
             raise RuntimeError("RPC credentials not configured")
         payload = {"jsonrpc": "1.0", "id": "lynx-tui", "method": method, "params": params or []}
         response = requests.post(
             self._rpc_url(),
             auth=(self.rpc_user, self.rpc_password),
             json=payload,
             timeout=3,
         )
         response.raise_for_status()
         data = response.json()
         if data.get("error"):
             raise RuntimeError(data["error"])
         return data.get("result")
 
     def _safe_call(self, method: str, params: Optional[list] = None) -> Any:
         try:
             return self._rpc_call(method, params)
         except Exception:
             return None
 
     def _count_stakes(self, days: int) -> int:
         log_path = Path(self.working_dir) / "debug.log"
         if not log_path.exists():
             return 0
         cutoff = datetime.now(timezone.utc) - timedelta(days=days)
         count = 0
         for line in log_path.read_text(errors="ignore").splitlines():
             if "CheckStake(): New proof-of-stake block found" not in line:
                 continue
             try:
                 timestamp = line[:20]
                 ts = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
             except Exception:
                 continue
             if ts >= cutoff:
                 count += 1
         return count
 
     def fetch_snapshot(self) -> Dict[str, Any]:
         blockchain = self._safe_call("getblockchaininfo") or {}
         peers = self._safe_call("getpeerinfo") or []
         balance = self._safe_call("getbalance") or 0
         listunspent = self._safe_call("listunspent") or []
         address_groups = self._safe_call("listaddressgroupings") or []
 
         immature_utxos = 0
         for utxo in listunspent:
             confirmations = utxo.get("confirmations", 0)
             if 0 < confirmations < 31:
                 immature_utxos += 1
 
         stakes_24h = self._count_stakes(1)
         stakes_7d = self._count_stakes(7)
         yield_24h = round(stakes_24h * 100 / 288, 3)
         yield_7d = round(stakes_7d * 100 / 2016, 3)
 
         sync_state = "unknown"
         if isinstance(blockchain, dict):
             ibd = blockchain.get("initialblockdownload")
             sync_state = "synced" if ibd is False else "syncing"
 
         peer_count = len(peers) if isinstance(peers, list) else 0
         peer_list = ", ".join([p.get("addr", "?") for p in peers[:5]]) if peers else "-"
 
         daemon_status = "running" if blockchain else "unknown"
         staking_status = "unknown"
         if isinstance(blockchain, dict):
             staking_status = "unknown" if blockchain.get("initialblockdownload") else "staking"
 
         return {
             "wallet_balance": balance,
             "immature_utxos": immature_utxos,
             "stakes_24h": stakes_24h,
             "stakes_7d": stakes_7d,
             "yield_24h": yield_24h,
             "yield_7d": yield_7d,
             "daemon_status": daemon_status,
             "staking_status": staking_status,
             "sync_state": sync_state,
             "block_height": blockchain.get("blocks", "-") if isinstance(blockchain, dict) else "-",
             "peer_count": peer_count,
             "peer_list": peer_list,
             "address_groups": len(address_groups) if isinstance(address_groups, list) else 0,
             "rpc_port": self.rpc_port or "8332",
             "rpc_security": "secure" if self.rpc_user and self.rpc_password else "unsecure",
             "working_dir": self.working_dir,
         }
