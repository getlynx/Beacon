 import asyncio
 from datetime import datetime, timezone
 
 from textual.app import App, ComposeResult
 from textual.containers import Container, Horizontal
 from textual.widgets import Footer, Header, Static, TabbedContent, TabPane
 
 from lynx_tui.services.logs import LogTailer
 from lynx_tui.services.pricing import PricingClient
 from lynx_tui.services.rpc import RpcClient
 
 
 class StatusBar(Static):
     def __init__(self) -> None:
         super().__init__()
         self.node_status = "unknown"
         self.block_height = "-"
         self.peers = "-"
         self.staking = "unknown"
         self.price_usd = "-"
         self.last_update = "-"
 
     def render(self) -> str:
         return (
             f"Node: {self.node_status} | Height: {self.block_height} | "
             f"Peers: {self.peers} | Staking: {self.staking} | "
             f"Price: {self.price_usd} | Updated: {self.last_update}"
         )
 
 
 class KeyValuePanel(Static):
     def __init__(self, title: str) -> None:
         super().__init__()
         self.title = title
         self.lines: list[str] = []
 
     def update_lines(self, lines: list[str]) -> None:
         self.lines = lines
         self.update(self.render())
 
     def render(self) -> str:
         content = "\n".join(self.lines) if self.lines else "Loading..."
         return f"[{self.title}]\n{content}"
 
 
 class LogsPanel(Static):
     def __init__(self, title: str) -> None:
         super().__init__()
         self.title = title
         self.lines: list[str] = []
 
     def update_lines(self, lines: list[str]) -> None:
         self.lines = lines[-200:]
         self.update(self.render())
 
     def render(self) -> str:
         content = "\n".join(self.lines) if self.lines else "No log output yet."
         return f"[{self.title}]\n{content}"
 
 
 class LynxTuiApp(App):
     BINDINGS = [
         ("q", "quit", "Quit"),
     ]
 
     CSS = """
     Screen {
         layout: vertical;
     }
     #body {
         height: 1fr;
     }
     #status-bar {
         height: 1;
     }
     """
 
     def __init__(self) -> None:
         super().__init__()
         self.rpc = RpcClient()
         self.pricing = PricingClient()
         self.logs = LogTailer()
 
         self.overview_panel = KeyValuePanel("Overview")
         self.wallet_panel = KeyValuePanel("Wallet")
         self.network_panel = KeyValuePanel("Network")
         self.system_panel = KeyValuePanel("System")
         self.logs_panel = LogsPanel("Debug Log")
         self.status_bar = StatusBar()
 
     def compose(self) -> ComposeResult:
         yield Header(show_clock=True)
         with Container(id="body"):
             with TabbedContent():
                 with TabPane("Overview"):
                     yield self.overview_panel
                 with TabPane("Wallet"):
                     yield self.wallet_panel
                 with TabPane("Network"):
                     yield self.network_panel
                 with TabPane("Logs"):
                     yield self.logs_panel
                 with TabPane("System"):
                     yield self.system_panel
         yield self.status_bar
         yield Footer()
 
     async def on_mount(self) -> None:
         self.set_interval(5, self.refresh_data)
         self.set_interval(2, self.refresh_logs)
 
     async def refresh_data(self) -> None:
         data = await asyncio.get_event_loop().run_in_executor(None, self.rpc.fetch_snapshot)
         price = await asyncio.get_event_loop().run_in_executor(None, self.pricing.fetch_price_usd)
 
         overview_lines = [
             f"Wallet balance: {data['wallet_balance']}",
             f"Immature UTXOs: {data['immature_utxos']}",
             f"24h stakes: {data['stakes_24h']} ({data['yield_24h']}%)",
             f"7d stakes: {data['stakes_7d']} ({data['yield_7d']}%)",
             f"Daemon: {data['daemon_status']}",
             f"Sync: {data['sync_state']}",
         ]
         self.overview_panel.update_lines(overview_lines)
 
         wallet_lines = [
             f"Addresses: {data['address_groups']}",
             "Send: use lynx-cli or future TUI form",
             "Sweep: use lynx-cli or future TUI form",
             "Backups: /var/lib/lynx-backup",
         ]
         self.wallet_panel.update_lines(wallet_lines)
 
         network_lines = [
             f"Peers: {data['peer_count']}",
             f"Peer list: {data['peer_list']}",
             f"Block height: {data['block_height']}",
         ]
         self.network_panel.update_lines(network_lines)
 
         system_lines = [
             f"RPC port: {data['rpc_port']}",
             f"RPC security: {data['rpc_security']}",
             f"Working dir: {data['working_dir']}",
             "Daemon control: systemctl start|stop lynx",
         ]
         self.system_panel.update_lines(system_lines)
 
         self.status_bar.node_status = data["daemon_status"]
         self.status_bar.block_height = data["block_height"]
         self.status_bar.peers = data["peer_count"]
         self.status_bar.staking = data["staking_status"]
         self.status_bar.price_usd = price if price else "-"
         self.status_bar.last_update = datetime.now(timezone.utc).strftime("%H:%M:%S UTC")
         self.status_bar.refresh()
 
     async def refresh_logs(self) -> None:
         lines = await asyncio.get_event_loop().run_in_executor(None, self.logs.tail_lines)
         self.logs_panel.update_lines(lines)
 
 
 def run() -> None:
     LynxTuiApp().run()
